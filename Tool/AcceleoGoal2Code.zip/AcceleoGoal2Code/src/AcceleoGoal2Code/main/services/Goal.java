package AcceleoFsm2Code.main;

public class Goal {
String name,decom,parent;
int status;
int visited;
public int getVisited() {
	return visited;
}
public void setVisited(int visited) {
	this.visited = visited;
}
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
public String getParent() {
	return parent;
}
public void setParent(String parent) {
	this.parent = parent;
}
public String getDecom() {
	return decom;
}
public void setDecom(String decom) {
	this.decom = decom;
}
int timeorder;

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getTimeorder() {
	return timeorder;
}
public void setTimeorder(int timeorder) {
	this.timeorder = timeorder;
}

}
