package AcceleoFsm2Code.main;
import java.util.concurrent.CopyOnWriteArrayList;
import java.sql.*;
import java.sql.ResultSet;
import java.io.*;
import java.util.*;
public class WorkflowGen 
{
	CopyOnWriteArrayList<String>workflowlist;
	CopyOnWriteArrayList<String>workflowlist2;
	HashMap<String,Integer>goalmaps;
	public static int funcImpSum;
	public WorkflowGen()
	{
		funcImpSum=0;
		goalmaps=new HashMap<String,Integer>();
		
		
		
	}
	public void generateWorkflow(CopyOnWriteArrayList<Goal>workflowgoals)
	{
		workflowlist=new CopyOnWriteArrayList<>();
		workflowlist2=new CopyOnWriteArrayList<>();
		System.out.println("\n\n\n ================================WorkFlow=====================");
		for(Goal g:workflowgoals)
		{
			//System.out.println(g.getName());
			if(!workflowlist.contains(g.getName()))
			{
				//System.out.println(g.getName());
				String gname=g.getName().trim();
				workflowlist.add(gname);
			}
		}
		
		for(String s:workflowlist)
		{
			System.out.println("Here "+s);
			int val=goalmaps.get(s);
			funcImpSum=funcImpSum*10+val;
		}
		System.out.println(funcImpSum);
		try
		{
			String drivername="com.microsoft.sqlserver.jdbc.SQLServerDriver";
			Class.forName(drivername);
			String db="jdbc:sqlserver://localhost:1433;user=sa;password=password;databaseName=sample";
			Connection con=DriverManager.getConnection(db);
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("Select * from workflowfiles where fileid="+funcImpSum);
			String filename="";
			while(rs.next())
			{
				filename=rs.getString(2);
			}
			PrintStream ps=new PrintStream(new File("..\\workflow2code\\workflow.txt"));
			
			FileReader fr=new FileReader(filename);
			BufferedReader br=new BufferedReader(fr);
			String line=br.readLine();
			
			while(line!=null)
			{
				ps.println(line);
				
				StringTokenizer st=new StringTokenizer(line, ">>");
				while(st.hasMoreTokens())
				{
					
					String token=st.nextToken();
					//System.out.println(token);
					
					token=token.trim();
					workflowlist2.add(token);
				}
				line=br.readLine();
			}
			ps.close();
			fr.close();
			br.close();
			
			CodeSelectionUI csu=new CodeSelectionUI(workflowlist2, new HashMap<String,String>());
			csu.setVisible(true);
		}
		catch(Exception e)
		{
			System.err.println("Invalid SQL-Server Table fsmData2");
		}
	}

}
