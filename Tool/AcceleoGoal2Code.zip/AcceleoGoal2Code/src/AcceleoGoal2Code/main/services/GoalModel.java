package AcceleoFsm2Code.main;
import javax.swing.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.awt.*;
import java.awt.geom.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.awt.event.*;
import java.sql.*;
class GUIGoal extends JFrame
{
	MyShapePanel drawPanel;
	MyShapePanel12 drawPanel2;
	
	String parName;
	public GUIGoal(String goalname)
	{
		
		setSize(1100,700);
		setTitle("Goal Model");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setLayout(null);
		
		drawPanel=new MyShapePanel(goalname);
		drawPanel.setBounds(10, 10,600, 700);
		add(drawPanel);
		drawPanel2=new MyShapePanel12();
		//drawPanel.setSize(400, 400);
		drawPanel2.setBounds(650, 50,400, 400);
		
		add(drawPanel2);
		
	}
}

class MyShapePanel extends JPanel
{
	Connection con=null;
	Statement stmt=null;
	CopyOnWriteArrayList<GoalInfo> GuideShapes;
	Shape SampleCircle;
	Shape circle1,circle;
	ArrayList<Shape>shapeList;
	int Clicked=0;
	Point p;
	CopyOnWriteArrayList<GoalInfo> ShapeLists;
	public static CopyOnWriteArrayList<Goal> workflowGoals;
	static String parentName="";
	int x=150,y=50;
	JButton jbworkflow;
	Color col;
	static JLabel jl,jl2,samplelabel;
	static Stack<String>goalStack;
	public static Stack <String> goalStack2;
	CopyOnWriteArrayList<GoalInfo> GoalWorkflowList;
	CopyOnWriteArrayList<Goal> FinalGoalList;
	public static CopyOnWriteArrayList<Goal> stackGoalList;
	
	public MyShapePanel(String goalname)
	{
		
		setBackground(Color.gray);
			jl=new JLabel();
			jl2=new JLabel();
			setLayout(null);
			jl.setBounds(10, 10, 350, 30);
			jl2.setBounds(10, 5, 340, 30);
//		for(String actr:ActorList)
//		{
				
			
			//jl2.setText("Select ProvideHeathCare");
			jl2.setText("Select "+goalname);
			jbworkflow=new JButton("Generate Workflow");
			jbworkflow.setBounds(50,600,150,20);
			add(jl);
			add(jl2);
			add(jbworkflow);
			ShapeLists=new CopyOnWriteArrayList();
			goalStack=new Stack<>();
			goalStack2=new Stack<>();
			parentName=new String();
			CopyOnWriteArrayList<Goal>goallistarr=new CopyOnWriteArrayList();
			workflowGoals =new CopyOnWriteArrayList<>();
			GoalWorkflowList=new CopyOnWriteArrayList<>();
			FinalGoalList=new CopyOnWriteArrayList<>();
			stackGoalList=new CopyOnWriteArrayList<>();
			ArrayList<Goal>goalarr=new ArrayList();
			goalarr=fetchGoals("G1");
			GoalInfo parinfo=new GoalInfo();
			parinfo.setId("none");
			circle1= new Ellipse2D.Double(x, y, 50, 50);
			
			//------------------------------------Guide---------------------------
			
			GuideShapes=new CopyOnWriteArrayList<>();
			SampleCircle= new Ellipse2D.Double(250, 575, 50, 50);
			col=Color.GREEN;
			GoalInfo goalinfox=new GoalInfo();
			goalinfox.setId("AND");
			goalinfox.setCol(col);
			goalinfox.setPoint(new Point(250,575));
			goalinfox.setShape(SampleCircle);
			GuideShapes.add(goalinfox);
			SampleCircle= new Ellipse2D.Double(310, 575, 50, 50);
			col=Color.BLUE;
			goalinfox=new GoalInfo();
			goalinfox.setId("OR");
			goalinfox.setCol(col);
			goalinfox.setPoint(new Point(310,575));
			goalinfox.setShape(SampleCircle);
			GuideShapes.add(goalinfox);
			SampleCircle= new Ellipse2D.Double(370, 575, 50, 50);
			col=Color.MAGENTA;
			goalinfox=new GoalInfo();
			goalinfox.setId("Marked");
			goalinfox.setPoint(new Point(360,575));
			goalinfox.setShape(SampleCircle);
			goalinfox.setCol(col);
			GuideShapes.add(goalinfox);
			SampleCircle= new Ellipse2D.Double(435, 575, 50, 50);
			col=Color.RED;
			goalinfox=new GoalInfo();
			goalinfox.setId("Root");
			goalinfox.setPoint(new Point(435,575));
			goalinfox.setShape(SampleCircle);
			goalinfox.setCol(col);
			GuideShapes.add(goalinfox);
			repaint();
			//------------------------------------------------------------------------
			col=Color.RED;
			Goal firstGoal=new Goal();
			//firstGoal.setName("ProvideHeathCare");
			firstGoal.setName(goalname);
			firstGoal.setParent("none");
			firstGoal.setDecom("null");
			firstGoal.setTimeorder(0);
			firstGoal.setStatus(0);
			workflowGoals.add(firstGoal);
			GoalInfo goalinfo=new GoalInfo();
			//goalinfo.setId("ProvideHeathCare");
			goalinfo.setId(goalname);
			goalinfo.setParent("none");
			goalinfo.setPoint(new Point(150,50));
			goalinfo.setShape(circle1);
			goalinfo.setCol(col);
			goalinfo.setParentInfo(parinfo);
			ShapeLists.add(goalinfo);
			repaint();
			//ShapeLists.clear();
			y=y+80;
			int goalcount=1;
			goalarr=fetchGoals("none");
			//goalarr=fetchGoals(goalname);
			goallistarr.addAll(goalarr);
			for(int i=0;i<goallistarr.size();i++)
			{
				Goal g=goallistarr.get(i);
				goalarr=findChildren(g);
				for(Goal g1:goalarr)
				{
					
						//System.out.println(g1.getName()+" Has parent "+g1.getParent());
						if(g1.getDecom().equalsIgnoreCase("or"))
						{
							col=Color.BLUE;
						}
						else
						{
							col=Color.GREEN;
						}
						if(goalcount==1)
						{
							x=x-40;
							String name=g1.getName();
							//System.out.println(g.getParent());
							circle1= new Ellipse2D.Double(x, y, 50, 50);
							GoalInfo goalinfo1=new GoalInfo();
							goalinfo1.setId(name);
							goalinfo1.setPoint(new Point(x,y));
							goalinfo1.setShape(circle1);
							goalinfo1.setParent(g1.getParent());
							System.out.println(goalinfo1.getId()+" and "+goalinfo1.getParent());
							goalinfo1.setDecomType(g1.getDecom());
							goalinfo1.setCol(col);
							for(GoalInfo gi:ShapeLists)
							{
								if(gi.getId().equalsIgnoreCase(goalinfo1.getParent()))
								{
									goalinfo1.setParentInfo(gi);
								}
							}
							GoalInfo tempg=goalinfo1.getParentInfo();
							int tempy=tempg.getPoint().y;
							tempy=tempy+70;
							int tempx=tempg.getPoint().x;
							tempx=tempx-50;
							tempx=tempx+60;
//							circle1= new Ellipse2D.Double(x, y, 50, 50);
//							goalinfo1.setPoint(new Point(x,y));
							goalinfo1.setShape(circle1);
							ShapeLists.add(goalinfo1);
							x=x+60;
						}
						else
						{
							
							String name=g1.getName();
							circle1= new Ellipse2D.Double(x, y, 50, 50);
							GoalInfo goalinfo1=new GoalInfo();
							goalinfo1.setId(name);
							goalinfo1.setParent(g1.getParent());
							System.out.println(goalinfo1.getId()+" and "+goalinfo1.getParent());
							goalinfo1.setDecomType(g1.getDecom());
							goalinfo1.setPoint(new Point(x,y));
							goalinfo1.setShape(circle1);
							goalinfo1.setCol(col);
							for(GoalInfo gi:ShapeLists)
							{
								if(gi.getId().equalsIgnoreCase(goalinfo1.getParent()))
								{
									goalinfo1.setParentInfo(gi);
								}
							}
							GoalInfo tempg=goalinfo1.getParentInfo();
//							int tempy=tempg.getPoint().y;
//							tempy=tempy+70;
//							int tempx=tempg.getPoint().x;
//							tempx=(int) (tempx+Math.random()*100+50);
//							circle1= new Ellipse2D.Double(tempx, tempy, 50, 50);
//							goalinfo1.setPoint(new Point(tempx,tempy));
							
							//goalinfo1.setShape(circle1);
							ShapeLists.add(goalinfo1);
							x=x+60;
						}
						goalcount++;
					
				
					goallistarr.add(g1);
				}
				y=y+70;
				x=50;
				//goallistarr.addAll(findChildren(g));
				for(Goal gg: goallistarr)
				{
					System.out.println("goal names "+gg.getName()+gg.getDecom()+gg.getParent()+gg.getTimeorder());
				}
			}
			
			jbworkflow.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					//JOptionPane.showMessageDialog(MyShapePanel.this,"Button Clicked.","Alert",JOptionPane.ERROR_MESSAGE);
					for(GoalInfo g:GoalWorkflowList)
					{
						//System.out.println("button clicked "+g.getId()+" "+g.getDecomType()+" "+g.getParent()+" ");
						for(Goal gol:goallistarr)
						{
							if(g.getId().equalsIgnoreCase(gol.getName()))
							{
								FinalGoalList.add(gol);
							}
							
						}
					}
//					for(Goal gol:FinalGoalList)
//					{
//						
//						System.out.println("Button Clicked "+gol.getName()+" "+gol.getParent()+" "+gol.getDecom()+" "+gol.getTimeorder());
//					}
					ArrayList<String> goals=new ArrayList();
					HashMap<String,String>hm=new HashMap();
					hm.put("G2", "");
					hm.put("G1", "");
					goals.add("G1");
					goals.add("G2");
					goals.add("G3");
					//WorkFlowGenerator wfg=new WorkFlowGenerator();
					//WorkFlowGeneration2 wfg=new WorkFlowGeneration2();
					//wfg.findLeaves(FinalGoalList);
					//CodeSelectionUI cs=new CodeSelectionUI(goals,hm);
					//cs.setVisible(true);
					WorkflowGen wg=new WorkflowGen();
					wg.generateWorkflow(workflowGoals);
					
				}
			});	
			
		
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				super.mouseClicked(me);
				String lblgoalname=jl2.getText();
				System.out.println("What is heaven "+lblgoalname);
				lblgoalname=lblgoalname.replace("Select", "");
				//lblgoalname=lblgoalname.trim();
				System.out.println("What the hell"+lblgoalname+"yess");
//				jl.setText("");
//				jl2.setText("");
				
				try{
					for(GoalInfo g :ShapeLists)
					{
						Shape s=g.getShape();
						if(s.contains(me.getPoint()))
						{
							if(s instanceof Rectangle2D)
							{
								System.out.println("Rectagle Clicked");
								
							}
							else if(s instanceof Ellipse2D)
							{
								System.out.println("Goal meeeee"+g.getId()+" Clicked");
								for(Goal gr:stackGoalList)
								{
									if(gr.getName().equalsIgnoreCase(g.getId()))
									{
										
										stackGoalList.remove(gr);
										gr.setVisited(1);
										stackGoalList.add(gr);
									}
								}
								int present=0;
								if(!MyShapePanel12.goalarraylist.isEmpty())
								{
									for(Goal gl:MyShapePanel12.goalarraylist)
									{
										if(g.getId().equalsIgnoreCase(gl.getName()))
										{
											present=1;
										}
									}
									if(present==0)
									{
										JOptionPane.showMessageDialog(MyShapePanel.this,"You have Selected Wrong Goal.","Alert",JOptionPane.ERROR_MESSAGE);  
										System.exit(0);
									}
								}
//								int k=complexandHandling(g);
//								if(k==1)
//								{
//									//right choice
//									System.out.println("Right choice good job");
//								}
//								else
//								{
//									JOptionPane.showMessageDialog(MyShapePanel.this,"You have Selected Wrong Goal.","Alert",JOptionPane.ERROR_MESSAGE);  
//									System.exit(0);
//								}
								Goal workflowgoal=new Goal();
								workflowgoal.setName(g.getId());
								workflowgoal.setParent(g.getParent());
								workflowgoal.setDecom(g.getDecomType());
								workflowgoal.setStatus(0);
								workflowGoals.add(workflowgoal);
								if(lblgoalname.contains(g.getId()))
								{
									int timeordergol=0;
									String poppeditem="",pop2="";
									for(Goal gk:MyShapePanel12.goalarraylist)
									{
										System.out.println("Goals available "+gk.getName());
										if(g.getId().equalsIgnoreCase(gk.getName()))
										{
											timeordergol=gk.getTimeorder();
										}
									}
									for(Goal gk:MyShapePanel12.goalarraylist)
									{
										if(gk.getTimeorder()<timeordergol)
										{
											JOptionPane.showMessageDialog(MyShapePanel.this,"You have Selected Wrong Goal. Select "+gk.getName(),"Alert",JOptionPane.ERROR_MESSAGE);  
											System.exit(0);
										}
									}
									try{
										 poppeditem=goalStack.pop();
										goalStack.push(poppeditem);
										System.out.println("Popped Item is "+poppeditem);
									}
									catch(Exception e)
									{
										
									}
									System.out.println("Every thing is ok now "+g.getId()+" select "+poppeditem);
									 
									g.setClicked(1);
									Clicked=1;
									p=me.getPoint();
									parentName=g.getId();
									//System.out.println("Hello this is test"+parentName);
									GoalWorkflowList.add(g);
									//new GUIGoal1(parentName).setVisible(true);
									MyShapePanel12 mp=new MyShapePanel12();
									mp.addGoal(parentName);
									
									searchClickedGoal(p);
									repaint();
									
								}
								else if(!goalStack.isEmpty() && g.getId().equalsIgnoreCase(goalStack.pop()))
								{
									System.out.println("Again I fix this everything is ok"+g.getId());
								}
								else
								{
									if(!goalStack.isEmpty())
									{
										String poppedGoal=goalStack.pop();
										if(g.getId().equalsIgnoreCase(poppedGoal)&&lblgoalname=="")
										{
											System.out.println("I have to fix this "+poppedGoal);
											g.setClicked(1);
											Clicked=1;
											p=me.getPoint();
											parentName=g.getId();
											//System.out.println("Hello this is test"+parentName);
											GoalWorkflowList.add(g);
											//new GUIGoal1(parentName).setVisible(true);
											MyShapePanel12 mp=new MyShapePanel12();
											mp.addGoal(parentName);
											
											searchClickedGoal(p);
											repaint();
										}
										else
										{
											if(goalStack2.isEmpty())
											{
												System.out.println("Everything is not ok goal stack empty"+g.getId());
												jl.setText("You have selected wrong goal. Exiting...");
												//int a=JOptionPane.showConfirmDialog(MyShapePanel.this,"You have Selected Wrong Goal.");  
												JOptionPane.showMessageDialog(MyShapePanel.this,"You have Selected Wrong Goal.","Alert",JOptionPane.ERROR_MESSAGE);  
												System.exit(0);
											}
											
											
										}
									}
									else
									{
										System.out.println("We have to work here now "+g.getId());
//										while(!goalStack2.isEmpty())
//											{
//												System.out.println("Hell this is "+goalStack2.pop());
//											}
										if(goalStack2.contains(g.getId()))
										{
											//I have to check whether the right goal is clicked or not, by comparing the time-orders
											int goaltime=0;
											for(Goal gg:stackGoalList)
											{
												System.out.println(gg.getName()+" Has time order "+gg.getTimeorder());
												if(gg.getName().equalsIgnoreCase(g.getId()))
												{
													goaltime=gg.getTimeorder();
												}
											}
											for(Goal gg:stackGoalList)
											{
												if(gg.getTimeorder()<goaltime && gg.getVisited()!=1)
												{
													JOptionPane.showMessageDialog(MyShapePanel.this,"You have Selected Wrong Goal. Select "+gg.getName(),"Alert",JOptionPane.ERROR_MESSAGE);  
													System.exit(0);
												}
											}
											System.out.println("Hey selected goals time order "+goaltime);
											System.out.println("Everything is ok"+g.getId());
											g.setClicked(1);
											Clicked=1;
											p=me.getPoint();
											parentName=g.getId();
											System.out.println("Hello this is test"+parentName);
											GoalWorkflowList.add(g);
											//new GUIGoal1(parentName).setVisible(true);
											MyShapePanel12 mp=new MyShapePanel12();
											mp.addGoal(parentName);
											searchClickedGoal(p);
											repaint();
										}
										else
										{
											System.out.println("Everything is not ok"+g.getId());
											jl.setText("You have selected wrong goal. Exiting...");
											//int a=JOptionPane.showConfirmDialog(MyShapePanel.this,"You have Selected Wrong Goal.");  
											JOptionPane.showMessageDialog(MyShapePanel.this,"You have Selected Wrong Goal.","Alert",JOptionPane.ERROR_MESSAGE);  
											System.exit(0);
										}
									}
									
//									
									
									
									
								}
//								g.setClicked(1);
//								Clicked=1;
//								p=me.getPoint();
//								parentName=g.getId();
//								System.out.println("Hello this is test"+parentName);
//								//new GUIGoal1(parentName).setVisible(true);
//								MyShapePanel12 mp=new MyShapePanel12();
//								mp.addGoal(parentName);
//								
//								searchClickedGoal(p);
//								repaint();
								
							}
							else
							{
								jl.setText("");
								jl2.setText("");
							}
						}
					}
				}
				catch(Exception e )
				{
					System.out.println(e.toString());
				}	
			}

			
		});
		//}//end of actor for
	}
	@Override
	protected void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		try{
			Graphics2D g2d = (Graphics2D) g;
			for (GoalInfo gi : GuideShapes) {
				//System.out.println("Hey I am expecting "+gi.getId());
				 Shape s=gi.getShape();
				 Color coll=gi.getCol();
		        	g2d.setColor(coll);
		            g2d.draw(s);
		            g2d.fill(s);
		            g2d.setColor(Color.BLACK);
		            g2d.drawString(gi.getId(), gi.getPoint().x+15,gi.getPoint().y+27);
			}
			if(Clicked==0)
			{

				 for (GoalInfo gi : ShapeLists) {
					 Shape s=gi.getShape();
					 //
					 Color coll=gi.getCol();
			        	g2d.setColor(coll);
			            g2d.draw(s);
			            g2d.fill(s);
			            g2d.setColor(Color.BLACK);
			            g2d.drawString(gi.getId(), gi.getPoint().x+15,gi.getPoint().y+27);
			           // System.out.println(gi.getId()+" "+gi.getParent());
			            
			        }
				 
				 // Drwing edges between nodes
				 for(GoalInfo g1:ShapeLists)
					{
					 	//System.out.println(g1.getId()+" "+g1.getParent());
					 	String par=g1.getParent();
					 	if(!par.equalsIgnoreCase("none"))
					 	{
					 		for(GoalInfo g2:ShapeLists)
								{
									
									if(g1.getParent().equalsIgnoreCase(g2.getId()))
									{
										 g2d.setColor(Color.BLACK);
										 g2d.drawLine(g2.getPoint().x+20, g2.getPoint().y+45, g1.getPoint().x+20,g1.getPoint().y);
									}
								}
					 	}
					 	
					}
			}
			else
			{
				for (GoalInfo gi : ShapeLists) {
					Shape s=gi.getShape();
					Color coll=gi.getCol();
					if(s.contains(p))
					{
						g2d.setColor(Color.MAGENTA);
			            g2d.draw(s);
			            g2d.fill(s);
			            g2d.setColor(Color.BLACK);
			            g2d.drawString(gi.getId(), gi.getPoint().x+15,gi.getPoint().y+27);
			            for(GoalInfo g1:ShapeLists)
						{
						 	//System.out.println(g1.getId()+" "+g1.getParent());
						 	String par=g1.getParent();
						 	if(!par.equalsIgnoreCase("none"))
						 	{
						 		for(GoalInfo g2:ShapeLists)
									{
										
										if(g1.getParent().equalsIgnoreCase(g2.getId()))
										{
											 g2d.setColor(Color.BLACK);
											 g2d.drawLine(g2.getPoint().x+20, g2.getPoint().y+45, g1.getPoint().x+20,g1.getPoint().y);
										}
									}
						 	}
						 	
						}
					}
					else if(gi.getClicked()!=1)
					{
						g2d.setColor(coll);
			            g2d.draw(s);
			            g2d.fill(s);
			            g2d.setColor(Color.BLACK);
			            g2d.drawString(gi.getId(), gi.getPoint().x+15,gi.getPoint().y+27);
			            for(GoalInfo g1:ShapeLists)
						{
						 	System.out.println(g1.getId()+" "+g1.getParent());
						 	String par=g1.getParent();
						 	if(!par.equalsIgnoreCase("none"))
						 	{
						 		for(GoalInfo g2:ShapeLists)
									{
										
										if(g1.getParent().equalsIgnoreCase(g2.getId()))
										{
											 g2d.setColor(Color.BLACK);
											 g2d.drawLine(g2.getPoint().x+20, g2.getPoint().y+45, g1.getPoint().x+20,g1.getPoint().y);
										}
									}
						 	}
						 	
						}
					}
					else
					{
						g2d.setColor(Color.MAGENTA);
			            g2d.draw(s);
			            g2d.fill(s);
			            g2d.setColor(Color.BLACK);
			            g2d.drawString(gi.getId(), gi.getPoint().x+15,gi.getPoint().y+27);
			            for(GoalInfo g1:ShapeLists)
						{
						 	System.out.println(g1.getId()+" "+g1.getParent());
						 	String par=g1.getParent();
						 	if(!par.equalsIgnoreCase("none"))
						 	{
						 		for(GoalInfo g2:ShapeLists)
									{
										
										if(g1.getParent().equalsIgnoreCase(g2.getId()))
										{
											 g2d.setColor(Color.BLACK);
											 g2d.drawLine(g2.getPoint().x+20, g2.getPoint().y+45, g1.getPoint().x+20,g1.getPoint().y);
										}
									}
						 	}
						 	
						}
					}
					
		            
		        }
			}
			
		}
		catch(Exception e)
		{
			
		}
	}
	public int complexandHandling(GoalInfo g)
	{
		int selectedgoaltimeorder=0;
		for(Goal gg:MyShapePanel12.goalarraylist)
		{
			if(g.getId().equalsIgnoreCase(gg.getName()))
			{
				selectedgoaltimeorder=gg.getTimeorder();
				break;
			}
		}
		int status=1;
		for(Goal gg:MyShapePanel12.goalarraylist)
		{
			if(!g.getId().equalsIgnoreCase(gg.getName()))
			{
				if(selectedgoaltimeorder>gg.getTimeorder())
				{
					status=0;
				}
			}
			
		}
		return status;
		
	}
	public ArrayList<Goal> findChildren(Goal parGoal)
	{
		String name=parGoal.getName();
		ArrayList<Goal>childGoals=new ArrayList();
		try
		{
			String drivername="com.microsoft.sqlserver.jdbc.SQLServerDriver";
			Class.forName(drivername);
			String db="jdbc:sqlserver://localhost:1433;user=sa;password=cmsa019;databaseName=GRL2APK";
			con=DriverManager.getConnection(db);
			stmt=con.createStatement();
			System.out.println("Connected");
			ResultSet rs=stmt.executeQuery("Select * from goalData where parent='"+name+"'");
			while(rs.next())
			{
				Goal g=new Goal();
				g.setName(rs.getString(2));
				g.setParent(rs.getString(3));
				g.setDecom(rs.getString(5));
				g.setTimeorder(rs.getInt(4));
				childGoals.add(g);
			}
		}
		catch(Exception e)
		{
			
		}
		return childGoals;
	}
	public void searchClickedGoal(Point p)
	{
		try{
			
			for(GoalInfo g:ShapeLists)
			{
				Shape s=g.getShape();
				if(s.contains(p))
				{
					String decom=g.getDecomType();
					String Parent=g.getParent();
					for(GoalInfo g1:ShapeLists)
					{
						//System.out.println(g1.getId()+" has parent "+g1.getParent());
						Shape s1=g1.getShape();
						if(!s1.contains(p))
						{
							if(Parent.equalsIgnoreCase(g1.getParent()))
							{
								String decomm=g1.getDecomType();
								if(decomm.equalsIgnoreCase("or"))
								{
									//ShapeLists.remove(g1.getId());
									ShapeLists.remove(g1);
									System.out.println("Removing "+g1.getId());
									removeChildren(g1.getId());
									repaint();
								}
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			
		}	
	}
	
	public void removeChildren(String parName)
	{
		try{
			for(GoalInfo gg:ShapeLists)
			{
				
				if(gg.getParent().equalsIgnoreCase(parName))
				{
					
					ShapeLists.remove(gg);
				}
			}
		}
		catch(Exception e)
		{
			
		}
	}
	
	
	public ArrayList<Goal> fetchGoals(String goal)
	{
		ArrayList<Goal> goals=new ArrayList();
		try
		{
			String drivername="com.microsoft.sqlserver.jdbc.SQLServerDriver";
			Class.forName(drivername);
			String db="jdbc:sqlserver://localhost:1433;user=sa;password=cmsa019;databaseName=GRL2APK";
			con=DriverManager.getConnection(db);
			stmt=con.createStatement();
			System.out.println("Connected");
			ResultSet rs=stmt.executeQuery("Select * from goalData where parent='"+goal+"'");
			while(rs.next())
			{
				Goal g=new Goal();
				g.setName(rs.getString(2));
				g.setParent(rs.getString(3));
				g.setDecom(rs.getString(5));
				goals.add(g);
			}
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
		}
		return goals;
	}
	
}
class MyShapePanel12 extends JPanel
{
	static Connection con=null;
	static Statement stmt=null;
	static Shape circle1;
	static Shape crcle;
	int goalcount=0;
	static int x;
	static int y;
	static int Clicked2=0;
	Point p;
	static Color col;
	static CopyOnWriteArrayList<GoalInfo> testShapeLists;
	static CopyOnWriteArrayList<Goal> goalarraylist;
	JButton btn;
	public MyShapePanel12(int a)
	{
		
	}
	public MyShapePanel12()
	{
		setBackground(Color.pink);
		//goalcount=countGoals();
		//System.out.println("Number of goals is "+goalcount);	
//		for(int i=0;i<goalcount;i++)
//		{
//			
//		}
		setLayout(null);
		btn=new JButton(">>");
		btn.setBounds(2, 180, 50, 20);
		goalarraylist=new CopyOnWriteArrayList();
		testShapeLists=new CopyOnWriteArrayList<>();
		add(btn);
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				repaint();
				
			}
		});	
			
			//repaint();
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				super.mouseClicked(me);
				try{
					for(GoalInfo g :testShapeLists)
					{
						Shape s=g.getShape();
						if(s.contains(me.getPoint()))
						{
							 if(s instanceof Ellipse2D)
							{
								System.out.println("Goal this"+g.getId()+" Clicked");
								
								g.setClicked(1);
								Clicked2=1;
								p=me.getPoint();
								//searchClickedGoal(p);
								repaint();
								
							}
						}
					}
				}
				catch(Exception e )
				{
					
				}	
			}
		});
	}

	@Override
	protected void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponent(g);
		try{
			Graphics2D g2d = (Graphics2D) g;
			if(Clicked2==0)
			{
				 for (GoalInfo gi : testShapeLists) {
					 Shape s=gi.getShape();
					 
					 Color coll=gi.getCol();
			        	g2d.setColor(coll);
			            g2d.draw(s);
			            g2d.fill(s);
			            g2d.setColor(Color.BLACK);
			            g2d.drawString(gi.getId(), gi.getPoint().x+15,gi.getPoint().y+27);
			           // System.out.println(gi.getId()+" "+gi.getParent());
			            
			        }
				 
				 // Drwing edges between nodes
				 for(GoalInfo g1:testShapeLists)
					{
					 	System.out.println(g1.getId()+" "+g1.getParent());
					 	String par=g1.getParent();
					 	if(!par.equalsIgnoreCase("none"))
					 	{
					 		for(GoalInfo g2:testShapeLists)
								{
									
									if(g1.getParent().equalsIgnoreCase(g2.getId()))
									{
										 g2d.setColor(Color.BLACK);
										 g2d.drawLine(g2.getPoint().x+20, g2.getPoint().y+45, g1.getPoint().x+20,g1.getPoint().y);
									}
								}
					 	}
					 	
					}
			}
			else
			{
				for (GoalInfo gi : testShapeLists) {
					Shape s=gi.getShape();
					Color coll=gi.getCol();
					//System.out.println("Are you crazy? "+gi.getId()+" "+gi.getClicked()+" "+Clicked2);
					if(s.contains(p))
					{
						g2d.setColor(Color.MAGENTA);
			            g2d.draw(s);
			            g2d.fill(s);
			            g2d.setColor(Color.BLACK);
			            g2d.drawString(gi.getId(), gi.getPoint().x+15,gi.getPoint().y+27);
			            for(GoalInfo g1:testShapeLists)
						{
						 	System.out.println(g1.getId()+" "+g1.getParent());
						 	String par=g1.getParent();
						 	if(!par.equalsIgnoreCase("none"))
						 	{
						 		for(GoalInfo g2:testShapeLists)
									{
										
										if(g1.getParent().equalsIgnoreCase(g2.getId()))
										{
											 g2d.setColor(Color.BLACK);
											 g2d.drawLine(g2.getPoint().x+20, g2.getPoint().y+45, g1.getPoint().x+20,g1.getPoint().y);
										}
									}
						 	}
						 	
						}
					}
					else if(gi.getClicked()!=1)
					{
						g2d.setColor(coll);
			            g2d.draw(s);
			            g2d.fill(s);
			            g2d.setColor(Color.BLACK);
			            g2d.drawString(gi.getId(), gi.getPoint().x+15,gi.getPoint().y+27);
			            for(GoalInfo g1:testShapeLists)
						{
						 	System.out.println(g1.getId()+" "+g1.getParent());
						 	String par=g1.getParent();
						 	if(!par.equalsIgnoreCase("none"))
						 	{
						 		for(GoalInfo g2:testShapeLists)
									{
										
										if(g1.getParent().equalsIgnoreCase(g2.getId()))
										{
											 g2d.setColor(Color.BLACK);
											 g2d.drawLine(g2.getPoint().x+20, g2.getPoint().y+45, g1.getPoint().x+20,g1.getPoint().y);
										}
									}
						 	}
						 	
						}
					}
					else
					{
						g2d.setColor(Color.MAGENTA);
			            g2d.draw(s);
			            g2d.fill(s);
			            g2d.setColor(Color.BLACK);
			            g2d.drawString(gi.getId(), gi.getPoint().x+15,gi.getPoint().y+27);
			            for(GoalInfo g1:testShapeLists)
						{
						 	System.out.println(g1.getId()+" "+g1.getParent());
						 	String par=g1.getParent();
						 	if(!par.equalsIgnoreCase("none"))
						 	{
						 		for(GoalInfo g2:testShapeLists)
									{
										
										if(g1.getParent().equalsIgnoreCase(g2.getId()))
										{
											 g2d.setColor(Color.BLACK);
											 g2d.drawLine(g2.getPoint().x+20, g2.getPoint().y+45, g1.getPoint().x+20,g1.getPoint().y);
										}
									}
						 	}
						 	
						}
					}
					
		            
		        }
			}
		}
		catch(Exception e)
		{
			
		}
		
	}
	public static CopyOnWriteArrayList<Goal> fetchChildren(String parName)
	{
		CopyOnWriteArrayList<Goal> goalarray=new CopyOnWriteArrayList();
		try
		{
			String drivername="com.microsoft.sqlserver.jdbc.SQLServerDriver";
			Class.forName(drivername);
			String db="jdbc:sqlserver://localhost:1433;user=sa;password=cmsa019;databaseName=GRL2APK";
			con=DriverManager.getConnection(db);
			stmt=con.createStatement();
			System.out.println("Connected");
			ResultSet rs=stmt.executeQuery("Select * from goalData where parent='"+parName+"'");
			while(rs.next())
			{
				Goal g=new Goal();
				g.setName(rs.getString(2));
				g.setParent(rs.getString(3));
				g.setTimeorder(rs.getInt(4));
				g.setDecom(rs.getString(5));
				goalarray.add(g);
			}
		}
		catch(Exception e )
		{
			
		}
		return goalarray;
	}
	public static void addGoal(String parname)
	{
//		String lblgoalname=MyShapePanel.jl2.getText();
//		System.out.println("What is heaven "+lblgoalname);
//		lblgoalname=lblgoalname.replace("select", "");
//		
		 crcle= new Ellipse2D.Double(130,50 , 50, 50);	
		 GoalInfo goalinfo=new GoalInfo();
			goalinfo.setId(parname);
			goalinfo.setParent("none");
			goalinfo.setPoint(new Point(130,50));
			goalinfo.setShape(crcle);
			goalinfo.setCol(Color.RED);
			x=130;y=50;
			Clicked2=0;
			int andor=0;
			y=y+70;
			int goalcount=1;
			testShapeLists.add(goalinfo);
			goalarraylist=fetchChildren(parname);
			int size=goalarraylist.size();
			int sizecount=0;
			for(Goal g:goalarraylist)
			{
				if(g.getDecom().equalsIgnoreCase("or"))
				{
					col=Color.BLUE;
					andor=1;
					
				}
				else
				{
					
					col=Color.GREEN;
					andor=0;
					if(g.getTimeorder()==0)
					{
						sizecount++;
						//andWithoutTimeHandling();
					}
				}
				if(goalcount==1)
				{
					x=x-40;
					String name=g.getName();
					//System.out.println(g.getParent());
					circle1= new Ellipse2D.Double(x, y, 50, 50);
					GoalInfo goalinfo1=new GoalInfo();
					goalinfo1.setId(name);
					goalinfo1.setPoint(new Point(x,y));
					goalinfo1.setShape(circle1);
					goalinfo1.setParent(g.getParent());
					System.out.println(goalinfo1.getId()+" and "+goalinfo1.getParent());
					goalinfo1.setDecomType(g.getDecom());
					goalinfo1.setCol(col);
					testShapeLists.add(goalinfo1);
					x=x+60;
				}
				else
				{
					
					String name=g.getName();
					circle1= new Ellipse2D.Double(x, y, 50, 50);
					GoalInfo goalinfo1=new GoalInfo();
					goalinfo1.setId(name);
					goalinfo1.setParent(g.getParent());
					System.out.println(goalinfo1.getId()+" and "+goalinfo1.getParent());
					goalinfo1.setDecomType(g.getDecom());
					goalinfo1.setPoint(new Point(x,y));
					goalinfo1.setShape(circle1);
					goalinfo1.setCol(col);
					testShapeLists.add(goalinfo1);
					x=x+60;
				}
				goalcount++;
			}
			if(size!=0)
			{
				if(size==sizecount)
				{
					System.out.println("Hey I am in sizecount same "+size+" "+sizecount);
					andWithoutTimeHandling();
				}
			}
			
			if(andor==0)
			checkTimeOrder();
			else
				orHandling();
			//repaint();
	}
	public static void andWithoutTimeHandling()
	{
		String goals="Select goals in anyorder from ";
		System.out.println("Hey I am executing in without order");
		for(Goal g:goalarraylist)
		{
			goals=goals+" "+g.getName();
			MyShapePanel.goalStack2.push(g.getName());
		}
		MyShapePanel.jl2.setText(goals);
	}
	public static void orHandling()
	{
		String goals="Select any of ";
		for(Goal g:goalarraylist)
		{
			goals=goals+" "+g.getName();
		}
		MyShapePanel.jl2.setText(goals);
	}
	public static CopyOnWriteArrayList<Goal> sortArraylist(CopyOnWriteArrayList<Goal> goalarraylist2) {
		CopyOnWriteArrayList<Goal> glist=new CopyOnWriteArrayList<>();
		try
		{
			for(Goal g:goalarraylist2)
			{
				int min=g.getTimeorder();
				Goal mingoal=g;
				for(Goal g2:goalarraylist2)
				{
					if(!g.getName().equalsIgnoreCase(g2.getName()))
					{
						if(min>g2.getTimeorder())
						{
							min=g2.getTimeorder();
							mingoal=g2;
						}
					}
				}
				glist.add(mingoal);
				for(Goal g3:goalarraylist2)
				{
					if(g3.getName().equalsIgnoreCase(mingoal.getName()))
					{
						goalarraylist2.remove(g3);
					}
				}
			}
		}
		catch(Exception e)
		{
			
		}
		
		
		
		return glist;
	}
	public static void checkTimeOrder()
	{
		
		goalarraylist=sortArraylist(goalarraylist);
		//Goal g=goalarraylist.get(0);
		String msg="Select ";
		
		for(Goal g2:goalarraylist)
		{
			String g2name=g2.getName();
			if(!MyShapePanel.goalStack2.contains(g2name))
				{
					System.out.println("Stack pused "+g2name);
					MyShapePanel.goalStack2.push(g2name);
					MyShapePanel.stackGoalList.add(g2);
					MyShapePanel.goalStack.push(g2name);
				}
					msg=msg+g2.getName()+" then ";
			
		}
		MyShapePanel.jl2.setText(msg);
//		for(Goal g:goalarraylist)
//		{
//			int gt1=g.getTimeorder();
//			String gname=g.getName();
//			for(Goal g2:goalarraylist)
//			{
//				String g2name=g2.getName();
//				int gt2=g2.getTimeorder();
//				if(!g2name.equalsIgnoreCase(gname)) // Here I have to find the sorted array in ascending order and push them one by one in stack. Because and decom can be more than one 
//				{
//					if(gt1>0 && gt2>0)
//					{
//						if(gt1<gt2)
//						{
//							MyShapePanel.jl.setText(gname+" is to be selected First after that "+g2name);
//							MyShapePanel.jl2.setText("Select "+gname);
//							if(!MyShapePanel.goalStack.contains(g2name))
//							{
//								MyShapePanel.goalStack.push(g2name);
//							}
//							if(!MyShapePanel.goalStack.contains(gname))
//							{
//								MyShapePanel.goalStack.push(gname);
//							}
//						}
//						else if(gt1>gt2)
//						{
//							MyShapePanel.jl.setText(g2name+" is to be selected First after that "+gname);
//							MyShapePanel.jl2.setText("Select "+g2name);
//							if(!MyShapePanel.goalStack.contains(gname))
//							{
//								MyShapePanel.goalStack.push(gname);
//							}
//							if(!MyShapePanel.goalStack.contains(g2name))
//							{
//								MyShapePanel.goalStack.push(g2name);
//							}
//							
//						}
//						else
//						{
//							MyShapePanel.jl.setText("Select any of "+gname+" or "+g2name);
//						}
//					}
//					
//					
//				}
//			}
//		}
	}
	
	
}
public class GoalModel {

	public static void mainMethod(String goalname) {
		new GUIGoal(goalname).setVisible(true);
	}

}
