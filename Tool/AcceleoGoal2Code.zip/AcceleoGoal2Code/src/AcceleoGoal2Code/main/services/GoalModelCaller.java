package AcceleoFsm2Code.main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import javax.swing.*;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.StringTokenizer;
import java.util.concurrent.CopyOnWriteArrayList;
class ActorBasedGoalSelection extends JFrame
{
	JComboBox jcActor;
	JButton btnFetch;
	static Connection con=null;
	static Statement stmt=null;
	static ResultSet rs=null;
	public ActorBasedGoalSelection(CopyOnWriteArrayList<String>ActorList) {
		setSize(600,600);
		setTitle("Actor Based Goal Model Selection");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setLayout(null);
		jcActor=new JComboBox<>();
		jcActor.setBounds(100,100,100,30);
		btnFetch=new JButton("Fetch");
		btnFetch.setBounds(100,180,80,30);
		add(jcActor);
		add(btnFetch);
		
		populate(ActorList);
		btnFetch.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try
				{
					String actr=jcActor.getSelectedItem().toString();
					String drivername="com.microsoft.sqlserver.jdbc.SQLServerDriver";
					Class.forName(drivername);
					String db="jdbc:sqlserver://localhost:1433;user=sa;password=password;databaseName=GRL2APK";
					con=DriverManager.getConnection(db);
					stmt=con.createStatement();
					stmt.executeUpdate("insert into goalData(goal,parent, timeorder,decomtype,demands,actor) select goal, parent,timeorder, decomtype,demands,actor from fsmdata2 where actor='"+actr+"'");	 
					ResultSet rs=stmt.executeQuery("Select goal from goalData where actor='"+actr+"' and parent='none'");
					while(rs.next())
					{
						String rootgoal=rs.getString(1);
						System.out.println("Root goal "+rootgoal);
						
						GoalModel.mainMethod(rootgoal);
											
					}
			
					con.close();
					
				}
				catch(Exception e)
				{
					System.out.println(e.toString());
				}
				
			}
		});
		
		
	}
	public void populate(CopyOnWriteArrayList<String> actors)
	{
		jcActor.setModel(new DefaultComboBoxModel(actors.toArray()));
	}
}

public class GoalModelCaller {
	public static CopyOnWriteArrayList<String>ActorList;
	
	public static int multipleWindowpermission=0;
	public static void main(String[] args) {
		ActorList=new CopyOnWriteArrayList<String>();
		try
		{
			String actor="";
			//actor parsing
			FileReader fr=new FileReader("../AcceleoGoal2Code/target/actor.txt");
			BufferedReader br=new BufferedReader(fr);
			String line=br.readLine();
			while(line!=null)
			{
				line=line.trim();
				StringTokenizer st=new StringTokenizer(line);
				while(st.hasMoreTokens())
				{
					String token=st.nextToken();
					if(token.equalsIgnoreCase("Actor:"))
					{
						actor=st.nextToken();
						ActorList.add(actor);
						
					}
				}
				line=br.readLine();
			}
			new ActorBasedGoalSelection(ActorList).setVisible(true);
//			for(String actr:ActorList)
//			{
//				String drivername="com.microsoft.sqlserver.jdbc.SQLServerDriver";
//				Class.forName(drivername);
//				String db="jdbc:sqlserver://localhost:1433;user=sa;password=cmsa019;databaseName=GRL2APK";
//				con=DriverManager.getConnection(db);
//				stmt=con.createStatement();
//				
//				//stmt.executeUpdate("insert into goalData(goal,parent, timeorder,decomtype,demands,actor) select goal, parent,timeorder, decomtype,demands,actor from fsmdata2 where actor='"+actr+"'");
//				//ResultSet rs=stmt.executeQuery("Select goal from goalData where actor='"+actr+"' and parent='none'");
//				while(rs.next())
//				{
//					String rootgoal=rs.getString(1);
//					System.out.println("Root goal "+rootgoal);
//					
//					//GoalModel.mainMethod(rootgoal);
//					multipleWindowpermission=1;
//					if(multipleWindowpermission==1)
//					{
//						
//					}
//				}
//				//stmt.executeUpdate("delete from goalData");
////				con.close();
//				//
//			}
//			//GoalModel.mainMethod("ProvideHealthCare");
		}
		catch(Exception e)
		{
			System.err.println(e.toString());
		}
			
	}

}
