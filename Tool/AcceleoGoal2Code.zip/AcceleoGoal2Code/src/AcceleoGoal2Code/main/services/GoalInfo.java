package AcceleoFsm2Code.main;
import java.awt.Color;
import java.awt.Point;
import java.awt.Shape;

public class GoalInfo {
	String id,parent,decomType;
	GoalInfo parentInfo;
	public GoalInfo getParentInfo() {
		return parentInfo;
	}
	public void setParentInfo(GoalInfo parentInfo) {
		this.parentInfo = parentInfo;
	}
	public String getParent() {
		return parent;
	}
	public void setParent(String parent) {
		this.parent = parent;
	}
	public String getDecomType() {
		return decomType;
	}
	public void setDecomType(String decomType) {
		this.decomType = decomType;
	}
	Shape shape;
	Point point;
	
	int clicked=0;
	Color col;
	public Color getCol() {
		return col;
	}
	public void setCol(Color col) {
		this.col = col;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Shape getShape() {
		return shape;
	}
	public void setShape(Shape shape) {
		this.shape = shape;
	}
	public Point getPoint() {
		return point;
	}
	public void setPoint(Point point) {
		this.point = point;
	}
	public int getClicked() {
		return clicked;
	}
	public void setClicked(int clicked) {
		this.clicked = clicked;
	}
	
}
