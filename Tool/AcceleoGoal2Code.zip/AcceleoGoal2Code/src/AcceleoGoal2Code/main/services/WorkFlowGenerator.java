package AcceleoFsm2Code.main;
import java.sql.DriverManager;
import java.sql.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.*;
import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class CodeSelectionUI extends JFrame
{
	JList jlCode;
	JLabel lbl,lbl2;
	JButton btnFetch,btnConfirm,btnWrite;
	JComboBox jcGoal,jcnfr;
	Connection con=null;
	Statement stmt=null;
	ResultSet rs=null;
	FileWriter fw=null;
	JCheckBox jcboxnfr;
	 Boolean checked=false;
	CopyOnWriteArrayList<String> nfrs,seletednfrop;
	CodeSelectionUI(CopyOnWriteArrayList<String> goals, HashMap<String,String>workflowMap)
	{
		setSize(900,600);
		setTitle("Method Signature Selection");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setLayout(null);
		jlCode=new JList();
		nfrs=new CopyOnWriteArrayList<String>();
		seletednfrop=new CopyOnWriteArrayList<String>();
		lbl=new JLabel("Choose Goal");
		lbl2=new JLabel("Choose NFR");
		btnFetch=new JButton("Fetch");
		btnConfirm=new JButton("Confirm");
		btnWrite=new JButton("Write");
		jcboxnfr=new JCheckBox("Tick to fetch NFR operationalization",false);
		jcboxnfr.setBounds(5,105,150,20);
		add(jcboxnfr);
		jcGoal=new JComboBox<>();
		jcnfr=new JComboBox<>();
		lbl.setBounds(5, 30, 100, 20);
		lbl2.setBounds(5,60,100,20);
		add(lbl);
		add(lbl2);
		jcGoal.setBounds(110, 30, 100, 30);
		jcnfr.setBounds(110, 70, 100, 30);
		add(jcGoal);
		jlCode.setBounds(275, 30, 400, 400);
		add(jlCode);
		btnFetch.setBounds(10, 200, 80, 30);
		add(btnFetch);
		btnConfirm.setBounds(110, 200, 80, 30);
		add(btnConfirm);
		btnWrite.setBounds(275, 470, 80, 30);
		add(btnWrite);
		add(jcnfr);
		//newly added 25-6-2019
		
		try
		{
			String demands="";
			String drivername="com.microsoft.sqlserver.jdbc.SQLServerDriver";
			Class.forName(drivername);
			String db="jdbc:sqlserver://localhost:1433;user=sa;password=password;databaseName=GRL2APK";
			con=DriverManager.getConnection(db);
			stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select demands from goalData where demands<>'none'");
			while(rs.next())
			{
				demands=rs.getString(1);
				
			}
			StringTokenizer st=new StringTokenizer(demands,",");
			while(st.hasMoreTokens())
			{
				String s=st.nextToken().trim();
				//System.out.println(st.nextToken());
				//goals.add(s);
				nfrs.add(s);
				
			}
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
		}
		
		//end of newly added block
		
		populatenfrs(nfrs);
		populate(goals);
		btnFetch.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				//System.out.println("goal selected "+selectedGoal);
				 checked=jcboxnfr.isSelected();
				if(checked==true)
				{
					checked=true;
					JOptionPane.showMessageDialog(CodeSelectionUI.this,"You are going to select NFR operationalizations","Alert",JOptionPane.WARNING_MESSAGE);     
					try
					{
						
						String selectednfr=jcnfr.getSelectedItem().toString();
						DefaultListModel<String> l1 = new DefaultListModel<>();  
						String drivername="com.microsoft.sqlserver.jdbc.SQLServerDriver";
						Class.forName(drivername);
						String db="jdbc:sqlserver://localhost:1433;user=sa;password=password;databaseName=GRL2APK";
						con=DriverManager.getConnection(db);
						stmt=con.createStatement();
						System.out.println("Connected");
						ResultSet rs=stmt.executeQuery("select * from goalSignature where goal='"+selectednfr+"'");
						while(rs.next())
						{
							String returnType=rs.getString(3);
							String signature=rs.getString(4);
							signature=returnType+" "+signature;
							l1.addElement(signature);
							
							 
						}
						jlCode.setModel(l1);
						con.close();
					}
					catch(Exception e)
					{
						
					}
				
				}
				else
				{
					String selectedGoal=jcGoal.getSelectedItem().toString();
					checked=false;
					//JOptionPane.showMessageDialog(CodeSelectionUI.this,"Not Checked","Alert",JOptionPane.WARNING_MESSAGE);     
					try
					{
						DefaultListModel<String> l1 = new DefaultListModel<>();  
						String drivername="com.microsoft.sqlserver.jdbc.SQLServerDriver";
						Class.forName(drivername);
						String db="jdbc:sqlserver://localhost:1433;user=sa;password=password;databaseName=GRL2APK";
						con=DriverManager.getConnection(db);
						stmt=con.createStatement();
						System.out.println("Connected");
						ResultSet rs=stmt.executeQuery("select * from goalSignature where goal='"+selectedGoal+"'");
						while(rs.next())
						{
							String returnType=rs.getString(3);
							String signature=rs.getString(4);
							signature=returnType+" "+signature;
							l1.addElement(signature);
							
							 
						}
						jlCode.setModel(l1);
						con.close();
					}
					catch(Exception e)
					{
						
					}
				}
				
				
				
			}
		});
		
		btnConfirm.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				DefaultListModel<String> l1 = new DefaultListModel<>();  
				String signature=jlCode.getSelectedValue().toString();
				//newly added for only NFR signature
				try {
					StringTokenizer st=new StringTokenizer(signature);
					while(st.hasMoreTokens())
					{
						String sig=st.nextToken();
						sig=st.nextToken();
						StringTokenizer st2=new StringTokenizer(sig);
						while(st2.hasMoreTokens())
						{
							seletednfrop.add(st2.nextToken("("));
							System.out.println(st2.nextToken());
						}
					}
				}
				catch(Exception ex)
				{
					
				}
				
				
				//end of newly added block
				
				
				String goal=jcGoal.getSelectedItem().toString();
				System.out.println(goal+" "+signature);
				workflowMap.remove(goal);
				workflowMap.put(goal,signature);
//				for (Map.Entry<String,String> entry : workflowMap.entrySet())
//				{
//					System.out.println(entry.getKey()+" "+entry.getValue());
//				}
				if(checked==false)
				{
					jcGoal.removeItemAt(jcGoal.getSelectedIndex());
					jlCode.setModel(l1);
				}
				
			}
		});
		
		btnWrite.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					//newly added block 25-6-2019
					String op1="";
					String op2="";
					op1=seletednfrop.get(0);
					op2=seletednfrop.get(1);
					
						
						JOptionPane.showMessageDialog(CodeSelectionUI.this," "+op1+" and "+op2,"Alert",JOptionPane.WARNING_MESSAGE);     
						String drivername="com.microsoft.sqlserver.jdbc.SQLServerDriver";
						Class.forName(drivername);
						String db="jdbc:sqlserver://localhost:1433;user=sa;password=password;databaseName=GRL2APK";
						con=DriverManager.getConnection(db);
						stmt=con.createStatement();
						ResultSet rs=stmt.executeQuery("select * from tblconflict where op1='"+op1+"' and op2='"+op2+"'");
						while(rs.next())
						{
							JOptionPane.showMessageDialog(CodeSelectionUI.this,"Conflict between "+op1+" and "+op2+" is "+rs.getInt(4)+"%","Conflict Detected",JOptionPane.ERROR_MESSAGE); 
							JOptionPane.showMessageDialog(CodeSelectionUI.this," Sorry! Try again","Alert",JOptionPane.WARNING_MESSAGE);  
							System.exit(0);
							
							
						}
					
					
					//end of newly added block
					PrintStream ps=new PrintStream(new File("..\\workflow2code\\workflow2.txt"));
					ps.print(WorkflowGen.funcImpSum);
					System.out.println("Heyyyyyy This is "+WorkflowGen.funcImpSum);
					ps.println();
					
					//newly add 25-06-2019
					
					
					//end of newly added block
					for(String go:goals)
					{
						System.out.println(workflowMap.get(go));
						ps.print(workflowMap.get(go)+" >> ");
					}
					ps.print("stop()");
					ps.close();
				}
				catch(Exception e)
				{
					
				}
				//returnToBack();
				
			}
		});
	}
	public void populate(CopyOnWriteArrayList<String> goals)
	{
		jcGoal.setModel(new DefaultComboBoxModel(goals.toArray()));
	}
	public void populatenfrs(CopyOnWriteArrayList<String> nfrs)
	{
		jcnfr.setModel(new DefaultComboBoxModel(nfrs.toArray()));
	}
}
public class WorkFlowGenerator 
{
	Connection con=null;
	Statement stmt=null;
	ResultSet rs=null;
	FileWriter fw=null;
	public void findLeaves(CopyOnWriteArrayList<Goal>FinalGoalList)
	{
		ArrayList<String>leaves=new ArrayList();
		CopyOnWriteArrayList<Goal>leafList=new CopyOnWriteArrayList();
		CopyOnWriteArrayList<Goal>status=new CopyOnWriteArrayList();
		ArrayList<String>workflowList=new ArrayList();
		HashMap<String,String>workflowMap=new HashMap();
		try
		{
			fw=new FileWriter("E:\\workflow2code\\workflow.txt");
			String drivername="com.microsoft.sqlserver.jdbc.SQLServerDriver";
			Class.forName(drivername);
			String db="jdbc:sqlserver://localhost:1433;user=sa;password=password;databaseName=GRL2APK";
			con=DriverManager.getConnection(db);
			stmt=con.createStatement();
			System.out.println("Connected");
			ResultSet rs=stmt.executeQuery("select goal from goalData where goal not in (select parent from goalData)");
			while(rs.next())
			{
				leaves.add(rs.getString(1));
			}
			for(Goal g:FinalGoalList)
			{
				g.setStatus(0);
				status.add(g);
				if(leaves.contains(g.getName()))
				{
					leafList.add(g);
					
				}
			}
			
			System.out.println(" \n");
			for(Goal g:leafList)
			{
				String par="";
				if(g.getStatus()==0)
				{
					par=g.getParent();
					//CodeSignature c=new CodeSignature();
					//c.setWorkflow(g.getName());
					workflowList.add(g.getName());
					System.out.print(g.getName()+">>");
					workflowMap.put(g.getName(), "");
					fw.write(g.getName()+" >> ");
					g.setStatus(1);
				}
				
				for(Goal g1:status)
				{
					if(g1.getStatus()==0)
					{
						if(par.equalsIgnoreCase(g1.getParent()))
						{
							System.out.print(g1.getName()+">>");
							//CodeSignature c=new CodeSignature();
							//c.setWorkflow(g1.getName());
							workflowList.add(g1.getName());
							workflowMap.put(g1.getName(), "");
							fw.write(g1.getName()+" >> ");
							g1.setStatus(1);
						}
					}
				}
				
				
				for(Goal g2:status)
				{
					//System.out.println("Hii "+par);
					if(par.equalsIgnoreCase(g2.getName()))
					{
						//System.out.println("Hi "+g2.getName()+" "+g2.getStatus());
						if(g2.getStatus()==0)
						{
							System.out.print(par+">>");
							//CodeSignature c=new CodeSignature();
							//c.setWorkflow(par);
							workflowList.add(par);
							workflowMap.put(par, "");
							fw.write(par+" >> ");
							g2.setStatus(1);
						}
						
					}
				}
				//System.out.println("leaves "+g.getName()); 
			}
			int flag=0;
			for(Goal g:FinalGoalList)
			{
				if(g.getName().equalsIgnoreCase("G4"))
				{
					flag=1;
				}
			}
			if(flag==1)
			{
				System.out.print("G3>>G1");
				//CodeSignature c=new CodeSignature();
				//c.setWorkflow("G3");
				workflowList.add("G3");
				//CodeSignature c1=new CodeSignature();
				//c1.setWorkflow("G1");
				workflowList.add("G1");
				workflowMap.put("G3", "");
				workflowMap.put("G1", "");
				fw.write("G3 >> G1");
			}
			else
			{
				System.out.print("G1");
				//CodeSignature c1=new CodeSignature();
				//c1.setWorkflow("G1");
				workflowList.add("G1");
				workflowMap.put("G1", "");
				fw.write("G1");
			}
			fw.close();
			//CodeSelectionUI cs=new CodeSelectionUI(workflowList,workflowMap);
			//cs.setVisible(true);
		}
		catch(Exception e)
		{
			
		}
	}
}
