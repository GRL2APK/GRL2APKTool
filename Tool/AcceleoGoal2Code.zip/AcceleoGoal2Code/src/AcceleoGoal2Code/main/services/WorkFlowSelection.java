package AcceleoFsm2Code.main;
import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
class WorkFlowInterface extends JFrame
{
	String func="",op="",parameter="";
	static int clickcount=0;
	JLabel nfr,fr,operator,param;
	JComboBox<ArrayList> nfrcombo;
	JComboBox<ArrayList> frcombo;
	JComboBox operatorcombo,paramcombo;
	JButton btncreate,btnaddparam;
	public WorkFlowInterface()
	{
		setSize(600,400);
		setTitle("WorkFlow Selection");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		nfr=new JLabel("Choose Functional Requirements and Non Functional Requirements");
		fr=new JLabel("Choose Requirements");
		setLayout(null);
		ArrayList<String>nfrlist=new ArrayList<>();
		nfrlist=readNFR();
		//nfrcombo=new JComboBox(nfrlist.toArray());
		ArrayList<String>frlist=new ArrayList<>();
		frlist=readFR();
		for(String d:nfrlist)
		{
			frlist.add(d);
		}
		frcombo=new JComboBox(frlist.toArray());
		nfr.setBounds(20,20,400, 40);
		//nfrcombo.setBounds(300, 30, 150, 20);
		frcombo.setBounds(300, 70, 150, 20);
		fr.setBounds(20,60,250, 40);
		operator=new JLabel("Select Operator");
		operator.setBounds(20,100,250,20);
		operatorcombo=new JComboBox<>();
		operatorcombo.addItem("Sequential");
		operatorcombo.addItem("Parallel");
		operatorcombo.setBounds(300, 100, 150, 20);
		param=new JLabel("Choose Parameter");
		param.setBounds(20,140,250,20);
		paramcombo=new JComboBox<>();
		paramcombo.addItem("int");
		paramcombo.addItem("String");
		paramcombo.addItem("double");
		paramcombo.addItem("ArrayList<String>");
		paramcombo.addItem("ArrayList<int>");
		paramcombo.setBounds(300, 140, 150, 20);
		btncreate=new JButton("Create");
		btncreate.setBounds(130,190,100,30);
		btnaddparam=new JButton("Add Param");
		btnaddparam.setBounds(300,170,100,30);
		//paramcombo.removeItem("int");
		add(fr);
		add(frcombo);
		add(nfr);
		//add(nfrcombo);
		add(operator);
		add(operatorcombo);
		add(param);
		add(paramcombo);
		add(btncreate);
		add(btnaddparam);
		
		//Button Click Events
		
		 btnaddparam.addActionListener(new ActionListener(){  
			    public void actionPerformed(ActionEvent e){  
			             
			             if(clickcount==0)
			             {
			            	 parameter=paramcombo.getSelectedItem().toString();
			            	 clickcount++;
			             }
			             else
			             {
			            	 parameter=parameter+","+paramcombo.getSelectedItem().toString();
			             }
			             
			    }  
			    }); 
		 
		 btncreate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				func=frcombo.getSelectedItem().toString();
				op=operatorcombo.getSelectedItem().toString();
				//System.out.println(func+" ")
			}
		});
		
		
	}
	public ArrayList<String>readNFR()
	{
		ArrayList<String>nfrlist=new ArrayList<>();
		BufferedReader br=null;
		try
		{
			br=new BufferedReader(new FileReader("E:\\wamp64\\www\\phpProject\\NFRCombination.txt"));
			String line=br.readLine();
			while(line!=null)
			{
				nfrlist.add(line);
				line=br.readLine();
			}
			br.close();
		}
		catch(Exception e)
		{
			
		}
		return nfrlist;
	}
	public ArrayList<String>readFR()
	{
		ArrayList<String>frlist=new ArrayList<>();
		BufferedReader br=null;
		try
		{
			br=new BufferedReader(new FileReader("E:\\wamp64\\www\\phpProject\\frs.txt"));
			String line=br.readLine();
			while(line!=null)
			{
				frlist.add(line);
				line=br.readLine();
			}
			br.close();
		}
		catch(Exception e)
		{
			
		}
		return frlist;
	}
}
public class WorkFlowSelection {

	public static void main(String[] args) {
		new WorkFlowInterface().setVisible(true);

	}

}
