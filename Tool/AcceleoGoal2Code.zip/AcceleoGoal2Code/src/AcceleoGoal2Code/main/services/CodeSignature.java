package AcceleoFsm2Code.main;
public class CodeSignature {
String workflow,signature;

public String getWorkflow() {
	return workflow;
}

public void setWorkflow(String workflow) {
	this.workflow = workflow;
}

public String getSignature() {
	return signature;
}

public void setSignature(String signature) {
	this.signature = signature;
}

}
