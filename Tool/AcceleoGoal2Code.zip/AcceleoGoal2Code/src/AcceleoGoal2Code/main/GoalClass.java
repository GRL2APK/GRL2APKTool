package AcceleoGoal2Code.main;

public class GoalClass 
{
	String goal,parent,decomType,actor;

	public String getDecomType() {
		return decomType;
	}

	public String getActor() {
		return actor;
	}

	public void setActor(String actor) {
		this.actor = actor;
	}

	public void setDecomType(String decomType) {
		this.decomType = decomType;
	}

	public String getGoal() {
		return goal;
	}

	public void setGoal(String goal) {
		this.goal = goal;
	}

	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}
	
}
